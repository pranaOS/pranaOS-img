#!/bin/bash
qemu_exec="qemu-system-arm"
qemu_smp=1
[[ -z "$PRANAOS_QEMU_ARM" ]] && qemu_exec='qemu-system-arm' || qemu_exec="$PRANAOS_QEMU_ARM"
[[ -z "$PRANAOS_QEMU_SMP" ]] && qemu_smp=1 || qemu_smp="$PRANAOS_QEMU_SMP"
$qemu_exec -M vexpress-a15 -cpu cortex-a15 -kernel ./base/boot/kernel.bin  -smp $qemu_smp -serial mon:stdio -vga std -drive id=disk,if=sd,format=raw,file=./pranaos.img
if [ $? -ne 0 ]; then echo -e "${ERROR} Run command failed" && exit 1; fi