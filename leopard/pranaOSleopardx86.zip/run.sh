#!/bin/bash
qemu_exec="qemu-system-i386"
qemu_smp=1
[[ -z "$PRANAOS_QEMU_X86" ]] && qemu_exec='qemu-system-i386' || qemu_exec="$PRANAOS_QEMU_X86"
[[ -z "$PRANAOS_QEMU_SMP" ]] && qemu_smp=1 || qemu_smp="$PRANAOS_QEMU_SMP"
$qemu_exec -m 256M --drive file=./os-image.bin,format=raw,index=0,if=floppy -device piix3-ide,id=ide -drive id=disk,format=raw,file=./pranaos.img,if=none -device ide-hd,drive=disk,bus=ide.0 -serial mon:stdio -rtc base=utc -vga std
if [ $? -ne 0 ]; then echo -e "${ERROR} Run command failed" && exit 1; fi